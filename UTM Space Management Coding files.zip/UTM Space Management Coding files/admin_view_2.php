<?php

$conn =mysqli_connect("localhost","root","","testfirst");

// $result = mysqli_query($conn, "SELECT" * FROM registration");
// WHERE gender='f'
$sql= "SELECT * FROM registration  ";

        $result= $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin view</title>
	
	<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #8b0000;}

.header {
  padding: 50px;
  text-align: center;
  background: #8b0000;
  color: white;
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #8b0000;
  box-sizing: border-box;
  background-color: #ddd;
}

button {
  background-color: #333;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}


button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.signup {
	width: auto;
	padding: 10px 18px;
	background-color: white;
}

.return {
	width: 5%;
	height: 7%;
	background-color: white;
	position: absolute;
  top: 40px;
  left: 50px;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 10%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}


@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}

.footer {
  text-align: center;
  padding: 3px;
  background-color: #8b0000;
  color: white;
}

.table-one tr{
  column-gap:140px;
}
table,th,tr,td {
  padding:10px;
  /* margin:30px; */
}

/* body{
  column-gap:140px;
} */

</style>

</head>
<body>

	<div class="container">
	
	<div class="header">
	<button type="button" class="return" style="padding: 0px 0px"><a href="Indexhomepage.php"><img src="utmlogo.jpg"
     alt="home"
	 style="width:200%;height:200%;"/></a></button>
    <h1>WELCOME, ADMIN </H1>
 <h2>BOOKING REQUEST DETAILS</h2>    
	</div>
	
	<hr>


    <?php
    if (mysqli_num_rows($result) > 0){
        ?>
        <table class="table-one">
        <tr>
        <th>Booking ID</th>
            <th>Lecturer Name</th>
            <th>Date</th>
            <th>Choice</th>
            <th>Timeslot</th>
            <th>Course</th>
        <th> Time of request</th>
        <th> Action</th>
        <th> Status</th>

       
        
        </tr>
        

        <?php
        $i=0;
        while ($row = mysqli_fetch_array($result)){
            ?>
        <tr>
            <td><?php echo $row["id"];?></td>
            <td><?php echo $row["firstName"];?></td>
            <td><?php echo $row["lastName"];?></td>
            <td><?php echo $row["gender"];?></td>
            <td><?php echo $row["email"];?></td>
            <td><?php echo $row["password"];?></td>
            <td><?php echo $row["time_req"];?></td>
            <td><?php echo $row["status"];?></td>
            <td> <a href="update.php?id=<?php echo $row["id"]; ?>">Update</a></td>
        </tr>
        <?php
        $i++;
        }
        ?>
        </table>
        <?php
    }
    else {
        echo "No result found";
    }
    ?>
	
	</div>
	
	<div class="footer">
		<p><b>Created by Team 2</b><br>
		<a href="mailto: nazatulkhaleeda@graduate.utm.my">nazatulkhaleeda@graduate.utm.my</a></p>
	</div>
	
</body>
</html>