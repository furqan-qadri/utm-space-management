<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
	
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}


input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

.header {
  padding: 10px;
  text-align: center;
  background: #8b0000;
  color: white;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #8b0000;
  margin-bottom: 25px;
}


button {
  background-color: #8b0000;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}


.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}


.cancelbtn, .submitbtn {
  float: left;
  width: 50%;
}

.return {
	width: 4%;
	height: 6%;
	background-color: white;
	position: absolute;
  top: 25px;
  left: 35px;
}


.container {
  padding: 16px;
}


.clearfix::after {
  content: "";
  clear: both;
  display: table;
}


@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}

.footer {
  text-align: center;
  padding: 3px;
  background-color:#8b0000;
  color: white;
}

</style>

</head>

<body>

<form  action="connect.php" style="border:1px solid #8b0000" method="post">
  <div class="container">
	
	<div class="header">
	<button type="button" class="return" style="padding: 0px 0px"><a href="Indexhomepage.php"><img src="utmlogo.jpg"
     alt="home"
	 style="width:200%;height:200%;"/></a></button>
    <h1>FORM COPY</h1>
    <p>Please fill in this form to book a room.</p>
	</div>
	
	<hr>
	
        <div>
            <label for="firstName"><b>Name</b></label>
            <input type="text" class="form-control" id="firstName" name="firstName" required>
        </div>

        <div>
            <label for="lastName"><b>Date</b></label>
            <input type="text" class="form-control" id="lastName" name="lastName" required>
        </div>

        <div>
            <label for="male">
            <input type="radio" name="gender" value="m" id="male"><b>Room 1</b></label>


            <label for="female">
                <input type="radio" name="gender" value="f" id="female"><b>Room 2</b></label>

                <label for="Both">
                    <input type="radio" name="gender" value="o" id="Both"><b>Room 3</b></label>

        </div>

		<br>

        <div>
            <label for="email"><b>Timeslot</b></label>
            <input type="text" id="email" name="email" required>
        </div>

        <div>
            <label for="password"><b>Course</b></label>
            <input type="text" id="password" name="password" required>
        </div>

        <div>
            <label for="number"><b>Additional requirements</b></label>
            <input type="text" id="number" name="number" required>
        </div>


        <div class="clearfix">
            <button type="button" class="cancelbtn"><a href="Homepage.html"><b>Cancel</b></a></button>
			<button type="submit" name="submit" class="submitbtn"><b>Submit</b></button>
        </div>

     
	 
	</div>
     <div class="footer">
		<p><b>Created by Team 2</b><br>
		<a href="mailto: nazatulkhaleeda@graduate.utm.my">nazatulkhaleeda@graduate.utm.my</a></p>
	</div>
    </form>
    
</body>
</html>