
<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$mysqli= NEW MySQLi ("localhost","root","","testfirst");

if (isset($_GET['order'])){
    $order= $_GET['order'];

}

else{
    $order='id';
}

if (isset($_GET['sort'])){
    $sort=$_GET['sort'];

}
else{
    $sort='ASC';
}

$resultSet= $mysqli->query("SELECT * FROM registration ORDER BY $order $sort");

if ($resultSet-> num_rows > 0){

    $sort == 'DESC' ? $sort='ASC' : $sort ='DESC';

    echo"
    <table border='1' >
    
    <tr>
    <th> <a href='?order=id && sort=$sort'>Request ID </a></th>
    <th> <a href='?order=time_req && sort=$sort'>Time of request</a></th>
    <th>Lecturer Name</th>
    <th>Date of booking</th>
    <th>Time slot</th>
    <th>Status</th>
    

    ";
    while ($rows=$resultSet->fetch_assoc())
    {
        $id= $rows['id'];
        $time_req= $rows['time_req'];
        $firstName=$rows['firstName'];
        $lastName=$rows['lastName'];
        $email=$rows['email'];
        $status=$rows['status'];

        echo"
        <tr>
        <td>$id</td>
        <td>$time_req</td>
        <td>$firstName</td>
        <td>$lastName</td>
        <td>$email</td>
        <td>$status</td>
        
        </tr>";
    }

    echo"
    </table>
    ";
}else {
    echo "No records returned.";
}



?>