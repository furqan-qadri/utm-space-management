<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Space manager View</title>
<style>
head{
	background-color: #5D001D;
	height: 160px;
	margin-bottom:100px;
}

body{
	background-color: rgb(233, 229, 224);
	margin-top:0px;
	padding:60px 0 0 0:
	background-image : url(path_to_logo) no-repeat top left;
}
table{
	margin-top:200px;
	background-color: rgb(219, 185, 190);
	padding-left: 30px;
	padding-rightl 30px;
	border-radius: 10px;
	}
button {
  background-color: #333;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

table,th,tr,td {
  padding:10px;
  /* margin:30px; */
}

</style>
</head>
<body>
    <h1>Welcome space manager.</h1>
    <h2>Bookings from all lecturers</h2>
    <br>
    <br>
    <br>

    <h2>Bookings from lecturer: Dr Zatul Alwani</h2>
    <table>
        <tr>
        <th>Lecturer Name</th>
            <th>Date</th>
            <th>Choice</th>
            <th>Timeslot</th>
            <th>Course</th>
            <th>Time of request</th>
            <th>Status</th>
        </tr>

        <?php
        $conn =mysqli_connect("localhost","root","","testfirst");

        $sql= "SELECT * FROM registration WHERE firstName='zatul' ";

        $result= $conn->query($sql);

        if ($result -> num_rows >0){
            while ($row = $result -> fetch_assoc()){
                echo "<tr><td>". $row["firstName"]. "</td><td>"
                .$row["lastName"]. 
                "</td> <td>". $row["gender"]. 
                "</td> <td>". $row["email"]. 
                "</td> <td>". $row["password"].
                "</td> <td>". $row["time_req"].
                "</td> <td>". $row["status"].
                
                "</td></tr>";
            }
        }
            else {
                echo "No results";
            }
        $conn->close();
        ?>
      
    </table>

    <h2>Bookings from lecturer: Dr Halinawati Hirol</h2>

    <table>
        <tr>
        <th>Lecturer Name</th>
            <th>Date</th>
            <th>Choice</th>
            <th>Timeslot</th>
            <th>Course</th>
            <th>Time of request</th>
            <th>Status</th>
        </tr>

        <?php
        $conn =mysqli_connect("localhost","root","","testfirst");

        $sql= "SELECT * FROM registration WHERE firstName='halina' ";

        $result= $conn->query($sql);

        if ($result -> num_rows >0){
            while ($row = $result -> fetch_assoc()){
                echo "<tr><td>". $row["firstName"]. "</td><td>"
                .$row["lastName"]. 
                "</td> <td>". $row["gender"]. 
                "</td> <td>". $row["email"]. 
                "</td> <td>". $row["password"].
                "</td> <td>". $row["time_req"].
                "</td> <td>". $row["status"].
                
                "</td></tr>";
            }
        }
            else {
                echo "No results";
            }
        $conn->close();
        ?>
      
    </table>

</body>
</html>