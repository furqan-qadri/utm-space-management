<?php
$conn =mysqli_connect("localhost","root","","testfirst");

if (count($_POST)>0){
    mysqli_query($conn, "UPDATE registration  set firstName=' " . $_POST['firstName'] . "', status='". $_POST['status']. "' WHERE id = '" .$_POST['id']. "'");
    $message=" record modified successfully";
}

$result= mysqli_query($conn, "SELECT * FROM registration where id='" .$_GET['id']."'");

$row=mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
</head>
<body>
    <form name="frmUser" method="post" action="">

    <div>
        <?php if(isset($message)) {
            echo $message;
        }
        ?>
    </div>

    <div>
        <a href="admin_view_2.php">List of requests</a>
    </div>

    <input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>"> First Name: <br>

    <input type="text" name="firstName" class="txtField" value="<?php echo $row['firstName']; ?>"> <br>

    <input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>"> Status: <br>


    <!-- <input type="text" name="status" class="txtField" value="<?php echo $row['status']; ?>"> <br> -->

    <input type="radio" id="contactChoice1"
     name="status" value="Approved">
    <label for="contactChoice1">Approved</label>

    <input type="radio" id="contactChoice2"
     name="status" value="Not Approved">
    <label for="contactChoice2">Not approved</label>


    <input type="submit" value="Submit" class="buttom">

    </form>
</body>
</html>